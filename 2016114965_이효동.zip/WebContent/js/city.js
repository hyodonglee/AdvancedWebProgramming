	$(function() {

		for (var cnt = 1; cnt <= 5; cnt++) {
			var banner = '#introducing-banner' + cnt;
			var comment = '#comment-str-id' + cnt;
			$(banner).css({
				"width" : "100%"
			});
			$(comment).css({
				"display" : "none"
			});
		}

		$(".comment-class").on({
			"click" : function(e) {
				e.preventDefault();

				var val = $(this).next().next().attr("id");
				val = '#' + val;

				$(val).slideToggle('fast');
			}
		});

		$(".heart").click(function(e) {
			e.preventDefault();
			var srcVal = $(this).attr("src");

			if (srcVal == 'images/others/heart-empty.png') {
				$(this).attr('src', 'images/others/heart.png');
			} else {
				$(this).attr('src', 'images/others/heart-empty.png');
			}
		});

		$(".banner-image").on({
			"mouseover" : function() {
				$(this).css({
					"cursor" : "pointer"
				});
			},

			"click" : function(e) {
				e.preventDefault();
				var srcVal = $(this).attr("src");
				var idVal = $(this).parent().prev().attr("id");

				idVal = '#' + idVal + '>img';

				$(idVal).attr('src', srcVal);

				var altVal = $(this).attr("alt");
				$(idVal).attr('alt', altVal);
			}
		});

	});